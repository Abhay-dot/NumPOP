import SpriteKit
import PlaygroundSupport


/*:
 # NumPOP
 In this playground, you will play the game **NumPOP**. There are 4 rounds and you have to clear all to win the game.
 
 In the game **NumPOP**, the goal is to "pop" two numbers (with the order in which you pop the number matters) from a group of floating numbers and use operators like  addition, subtraction, multiplication, and division to create the "Number: " displayed at the bottom of the screen.
 
 ## Note
 Before clicking on the Play button, you can have some fun with the emojis by clicking on them to hear the satisfying "pop" sound, or by creating new ones with your finger or cursor and observing how the numbers fill the screen.

 ## Scoring
 Each right answer gives you a +2, while each wrong answer gives you a -1.
 
 ## Rounds
There are four rounds: addition (round 1), subtraction (round 2), mutiplication (round 3) and division (round 4). Each level has a time limit of **40 seconds** with the objective of scoring a minimmum of **8 points** to advance to the next level
 */

//Constant Values for the game.
let width = 480
let height = 540

// Code to bring the game
let spriteView = SKView(frame: CGRect(x: 0, y: 0, width: width, height: height))

//Debugging commands
//spriteView.showsDrawCount = true
//spriteView.showsNodeCount = true
//spriteView.showsFPS = true

// Adding game to playground so that we all can play
let scene = MainScene(size: CGSize(width: width, height: height))
spriteView.presentScene(scene)

// Show in Playground live view
PlaygroundPage.current.liveView = spriteView

