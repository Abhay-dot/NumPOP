import Foundation
import SpriteKit
import GameKit

//Model for storing Number Information
class NumberModel {
    var number: String
    var numberValue: Int
    var numberTime: CGFloat
    var numberName: String
    
    init(number: String, numberValue: Int,numberTime: CGFloat) {
        self.number = number
        self.numberValue = numberValue
        self.numberTime = numberTime
        numberName = "\(numberValue)"
    }
    
    func getNumber() -> String {
        return self.number
    }
    
    func getNumberTime() -> CGFloat {
        return self.numberTime
    }
    
    func getNumberValue() -> Int {
        return self.numberValue
    }
}
