import SpriteKit
import GameKit

//Extending the Class SKSpriteNode to set the touchAblePoroperty of Button and other Elements.
class TouchableSrpiteNode : SKSpriteNode
{
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let fadeOutAction = SKAction.fadeOut(withDuration: 0.25)
        fadeOutAction.timingMode = .easeInEaseOut
        
        self.run(fadeOutAction, completion: {
            
            self.removeFromParent()
        })
    }
}

//Extending the Class SKLabelNode to set the touchAbleProperty of the number
protocol TouchableSpriteTextNodeDelegate: class {
    func didTap(sender: TouchableSpriteTextNode)
}

class TouchableSpriteTextNode : SKLabelNode
{
    var delegate : TouchableSpriteTextNodeDelegate!
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let action = SKAction.playSoundFileNamed("popSound.mp3", waitForCompletion: false)
        self.run(action)
        
        if let delegate = delegate
        {
            delegate.didTap(sender: self)
            return
        }
        let fadeOutAction = SKAction.fadeOut(withDuration: 0.05)
        fadeOutAction.timingMode = .easeInEaseOut
        self.run(fadeOutAction, completion: {
            self.removeFromParent()
        })
    }
}

public class MainScene: SKScene {
    
    // MARK: Properties
    let buttonNodeName = "button"
    
    // StringsForLocalization
    var isInitialScene = true
    let wwdcIconName = "wwdcIcon"
    let initialTextNodes = "welcome"
    let helloString = "Welcome"
    let namasteString = "to"
    let emojiHandString = "+ - × ÷"
    let welcomeString = ""
    let gameName = " NumPOP "
    
    
    // Game Timer and Score Label
    let roundIdentifier = "roundLabel"
    let timerIndentifier = "timerLabel"
    let scoreIdentifier = "scoreLabel"
    let rando = "randomNumberLabel"
    
    var timer : SKLabelNode = SKLabelNode()
    var score : SKLabelNode = SKLabelNode()
    var randNum: SKLabelNode = SKLabelNode()
    var sumShower: SKLabelNode = SKLabelNode()
    var N1: SKLabelNode = SKLabelNode()
    var N2: SKLabelNode = SKLabelNode()
    
    //Variables for Initial number Animation
    var lineWiseX : CGFloat = 0
    var lineWiseY : CGFloat = 0
    var jumpedAhead = false
    
    var sum: Double = 0
    var product: Double = 1
    var answer:Double = 0
    var count = 0
    var randNumber = GKRandomSource.sharedRandom().nextInt(upperBound: 16) + GKRandomSource.sharedRandom().nextInt(upperBound: 13)
    var textForRound = ["ADDITION !!!", "SUBTRACTION !!!", "MULTIPLICATION !!!", "Division !!!"]
    var symbolsOperators = ["+", "-", "x", "÷"]

    //numbers for Initial View
    let numbers = ["❶", "❷", "❸", "❹", "❺", "❻", "❼", "❽", "❾", "❿"]
    
    // Game Rules
    let noOfRounds = 4
    var currentRound = 1
    let totalTime = [40 ,40, 40, 40]
    let totalScore = [8,8,8,8]
    let totalnumbers = [32,32,32,32]
    var scoreValue = 0
    var isTimeOver = false
    //numberSetForRound
    var numbersRound : [NumberModel] = [NumberModel]()
    
    // MARK: Lifecycle
    override public func didMove(to view: SKView) {
        super.didMove(to: view)
        
        let background = SKSpriteNode(color: SKColor(red: 0.529, green: 0.888, blue: 0.972, alpha: 1), size: self.size)
        background.name = "background"
        background.setScale(1.5)
        background.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(background)
        
        setUpIntialScene()
        
        // setting Flower Textures
    }
    
    //Initial Welcome Scene
    func setUpIntialScene() {
        scaleMode = .resizeFill
        physicsWorld.gravity = CGVector.zero
        view?.isMultipleTouchEnabled = true
        
        let namaste = SKLabelNode(fontNamed: "Helvetica Neue")
        namaste.text = namasteString
        namaste.name = initialTextNodes
        //        namaste.zPosition = 0
        namaste.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: namaste.frame.width * 1.25 , height: namaste.frame.height * 2.5))
        namaste.physicsBody?.isDynamic = false
        namaste.fontSize = 30
        namaste.fontColor = SKColor.black
        namaste.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(namaste)
        namaste.alpha = 0
        
        var fadeOutAction = SKAction.fadeIn(withDuration: 3) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        namaste.run(fadeOutAction, completion: {
            namaste.alpha = 1
        })
        
        let hello = SKLabelNode(fontNamed: "Helvetica Neue")
        hello.text = helloString
        hello.name = initialTextNodes
        //        hello.zPosition = 0
        hello.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: hello.frame.width * 1.25 , height: hello.frame.height * 2.5))
        hello.physicsBody?.isDynamic = false
        hello.fontSize = 30
        hello.fontColor = SKColor.black
        hello.position = CGPoint(x: frame.midX , y: frame.midY + namaste.frame.height + 10)
        addChild(hello)
        hello.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 2) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        hello.run(fadeOutAction, completion: {
            hello.alpha = 1
        })
        
        let number = SKLabelNode(fontNamed: "Helvetica Neue")
        number.text = emojiHandString
        number.name = initialTextNodes
        //        emoji.zPosition = 0
        number.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: number.frame.width * 1.25 , height: number.frame.height * 2.5))
        number.physicsBody?.isDynamic = false
        number.fontSize = 40
        number.fontColor = SKColor.init(_colorLiteralRed: 0.2, green: 0.36, blue: 0.56, alpha: 1)
        number.position = CGPoint(x: frame.midX , y: frame.midY - (namaste.frame.height + 10) - 10)
        addChild(number)
        number.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 4) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        number.run(fadeOutAction, completion: {
            number.alpha = 1
        })
        
        let welcomeTo = SKLabelNode(fontNamed: "Helvetica Neue")
        welcomeTo.text = welcomeString
        welcomeTo.name = initialTextNodes
        //        welcomeTo.zPosition = 0
        welcomeTo.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: welcomeTo.frame.width * 1.25 , height: welcomeTo.frame.height * 2.5))
        welcomeTo.physicsBody?.isDynamic = false
        welcomeTo.fontSize = 20
        welcomeTo.fontColor = SKColor.black
        welcomeTo.position = CGPoint(x: frame.midX , y: frame.midY - (namaste.frame.height + 10) - (number.frame.height + 10))
        addChild(welcomeTo)
        
        welcomeTo.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 5) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        welcomeTo.run(fadeOutAction, completion: {
            welcomeTo.alpha = 1
        })
        
        let game = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        game.text = gameName
        game.name = initialTextNodes
        //        game.zPosition = 0
        game.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: game.frame.width * 1.25 , height: game.frame.height * 2.5))
        game.physicsBody?.isDynamic = false
        game.fontSize = 45
        game.fontColor = SKColor.init(_colorLiteralRed: 1, green: 0.36, blue: 0.53, alpha: 1)
        game.position = CGPoint(x: frame.midX , y: frame.midY - (namaste.frame.height + 10) - (number.frame.height + 10) - (welcomeTo.frame.height + 10) - 5)
        addChild(game)
        game.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 5) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        game.run(fadeOutAction, completion: {
            game.alpha = 1
        })
        
        
        let button = PlayButton()
        button.name = buttonNodeName
        button.position = CGPoint(x: frame.midX , y: frame.midY - (namaste.frame.height + 10) - (number.frame.height + 10) - (welcomeTo.frame.height + 10) - (game.frame.height + 10) - 5)
        button.delegate = self
        button.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: button.frame.width * 1.25 , height: button.frame.height * 2.5))
        button.physicsBody?.isDynamic = false
        button.alpha = 0
        addChild(button)
        
        addLinewisenumberElements()
        
    }
    
    //Function to add numbers in the Initial Scene
    func addLinewisenumberElements()
    {
        let wait = SKAction.wait(forDuration:0.026 )
        let action = SKAction.run {
            let point = CGPoint(x: self.lineWiseX, y: self.lineWiseY)
            self.createRandomnumber(at: point)
            self.lineWiseY = self.lineWiseY + 30
            
            if (!self.jumpedAhead && self.lineWiseY > 100 && self.lineWiseY < (self.frame.midY + 100)){
                self.lineWiseY = self.lineWiseY + 270
                self.jumpedAhead = true
            }
            
            if(self.lineWiseY >= self.frame.height + 160)
            {
                self.lineWiseY = 0
                self.jumpedAhead = false
                self.lineWiseX = self.lineWiseX + 30
            }
            if (self.lineWiseX >= self.frame.width)
            {
                self.removeAllActions()
                self.enumerateChildNodes(withName: self.buttonNodeName) { (node, stop) in
                    let fadeInAction = SKAction.fadeIn(withDuration: 0.25)
                    fadeInAction.timingMode = .easeInEaseOut
                    node.run(fadeInAction, completion: {
                        node.alpha = 1
                    })
                }
            }
        }
        
        run(SKAction.repeatForever(SKAction.sequence([wait, action])))
    }
    
    //function to Create Random number given a point
    func createRandomnumber(at point: CGPoint) {
        let randomnumberIndex = GKRandomSource.sharedRandom().nextInt(upperBound: numbers.count)
        
        let person = TouchableSpriteTextNode(fontNamed: "Helvetica Neue")
        person.text = numbers[randomnumberIndex]
        person.isUserInteractionEnabled = true
        person.name = wwdcIconName
        person.fontColor = SKColor.init(_colorLiteralRed: 0.651, green: 0.510, blue: 0.888, alpha: 1)
        person.fontSize = 40
        person.position = CGPoint(x: point.x, y: point.y)
        
        let maxRadius = max(person.frame.size.width/2, person.frame.size.height/2)
        let interPersonSeparationConstant: CGFloat = 1.25
        person.physicsBody = SKPhysicsBody(circleOfRadius: maxRadius*interPersonSeparationConstant)
        
        addChild(person)
    }
    
    //Function that shows the CountDown to the Level
    func roundCounter()
    {
        let roundText = "Round \(currentRound)"
        let round = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        round.text = roundText
        round.name = initialTextNodes
        round.fontSize = 50
        round.fontColor = SKColor.black
        round.position = CGPoint(x: frame.midX , y: frame.midY)
        addChild(round)
        round.alpha = 0
        var fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        round.run(fadeOutAction, completion: {
            round.alpha = 1
        })
        
        
        round.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 1.8) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        round.run(fadeOutAction, completion: {
            round.text = self.textForRound[self.currentRound-1]
        round.alpha = 1
        })

        round.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 3) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        round.run(fadeOutAction, completion: {
            round.text = "3"
            round.alpha = 1
        })
        round.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 4) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        round.run(fadeOutAction, completion: {
            round.text = "2"
            round.alpha = 1
        })
        round.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 5) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        round.run(fadeOutAction, completion: {
            round.text = "1"
            round.alpha = 1
            
        })
        
        fadeOutAction = SKAction.fadeIn(withDuration: 6.1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        round.run(fadeOutAction, completion: {
            round.text = "1"
            round.alpha = 1
            round.removeFromParent()
            self.setUpGameScene()
            
        })
    }
    
    //Function to Initiate the CountDown
    func setUpScene() {
        scaleMode = .resizeFill
        physicsWorld.gravity = CGVector.zero
        view?.isMultipleTouchEnabled = true
        
        self.removeAllActions()
        self.removeAllChildren()
        let background = SKSpriteNode(color: SKColor(red: 0.529, green: 0.888, blue: 0.972, alpha: 1), size: self.size)
        background.name = "background"
        background.setScale(1.5)
        background.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(background)
        
        // Starting the Round with showing a Counter
        roundCounter()
    }
    
    //Function to set the number Array
    func setnumberArray() {
        //Setting number Array with scoreValue and Time the number will stay
        for i in 1...15 {
            let number = NumberModel(number: "\(i)", numberValue: i, numberTime: 1)
            numbersRound.append(number)
        }
    }
    
    //Function to set Random Number in the game scene. Choose a Position Randomly.
    func addNumbersOnRandomPlaces() {
        if isTimeOver == true{
            return
        }
        
        var randomNumberIndex = GKRandomSource.sharedRandom().nextInt(upperBound: numbersRound.count)
        
        if (currentRound == 1) {
            while (randNumber == randomNumberIndex + 1) {
                randomNumberIndex = GKRandomSource.sharedRandom().nextInt(upperBound: numbersRound.count)
            }
        }
        
        let randomNumberPositionX = 10 +  GKRandomSource.sharedRandom().nextInt(upperBound: Int(self.frame.width - 20))
        let randomNumberPositionY = 50 + GKRandomSource.sharedRandom().nextInt(upperBound: Int(self.frame.height - 40))
        
        let number = TouchableSpriteTextNode(fontNamed: "Helvetica Neue-Bold")

        number.delegate = self
        number.text = numbersRound[randomNumberIndex].number
        number.isUserInteractionEnabled = true
        number.name = numbersRound[randomNumberIndex].numberName
        number.fontSize = 24
        number.position = CGPoint(x: CGFloat(randomNumberPositionX), y: CGFloat(randomNumberPositionY))
        number.fontColor = SKColor.init(_colorLiteralRed: Float(CGFloat.random(in: 0.42...1)), green: Float(CGFloat.random(in: 0...0.3)), blue: Float(CGFloat.random(in: 0.42...1)), alpha: 1)
        
        let maxRadius = max(number.frame.size.width/2, number.frame.size.height/2)
        let interPersonSeparationConstant: CGFloat = 2
        number.physicsBody = SKPhysicsBody(circleOfRadius: maxRadius*interPersonSeparationConstant)
        
        let randomTime = GKRandomSource.sharedRandom().nextInt(upperBound: 4)
        let time = numbersRound[randomNumberIndex].numberTime + CGFloat(randomTime) + 1.5
        let fadeOutAction = SKAction.fadeOut(withDuration: TimeInterval(time)) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        number.run(fadeOutAction, completion: {
            number.removeFromParent()
            self.addNumbersOnRandomPlaces()
        })
        addChild(number)
        
        let newSize = CGSize(width: 35, height: 35)
        let border = SKShapeNode(rectOf: newSize, cornerRadius: 17.5)
        
        border.strokeColor = SKColor.init(_colorLiteralRed: 0 , green: 0.1 , blue: 0, alpha: 1)
        border.lineWidth = 3
        border.position = CGPoint(x: 0, y: 10)
        number.addChild(border)
    }
    
    //Function to set the Game UI Elements and Initiate the Game
    func setUpGameScene() {
        let round = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        round.text = "Round \(currentRound)"
        round.name = roundIdentifier
        round.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: round.frame.width * 1.25 , height: round.frame.height * 2.5))
        round.physicsBody?.isDynamic = false
        round.fontSize = 20
        round.fontColor = SKColor.black
        round.position = CGPoint(x: 50 , y: self.frame.height - 25)
        addChild(round)
        round.alpha = 0
        var fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        round.run(fadeOutAction, completion: {
            round.alpha = 1
        })
        
        timer = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        timer.text = "Timer : \(self.totalTime[currentRound - 1])"
        timer.name = timerIndentifier
        //        game.zPosition = 0
        timer.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: timer.frame.width * 1.25 , height: timer.frame.height * 2.5))
        timer.physicsBody?.isDynamic = false
        timer.fontSize = 20
        timer.fontColor = SKColor.black
        timer.position = CGPoint(x: self.frame.width - 70 , y: self.frame.height - 25)
        addChild(timer)
        timer.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        timer.run(fadeOutAction, completion: {
            self.timer.alpha = 1
        })
        
        score = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        score.text = "Score : 0"
        score.name = scoreIdentifier
        //        game.zPosition = 0
        score.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: timer.frame.width * 1.25 , height: timer.frame.height * 2.5))
        score.physicsBody?.isDynamic = false
        score.fontSize = 20
        score.fontColor = SKColor.black
        score.position = CGPoint(x: 60 , y: 15)
        addChild(score)
        score.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        score.run(fadeOutAction, completion: {
            self.score.alpha = 1
        })
        
        randNum = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        randNum.text = "Number: \(randNumber)"
        randNum.name = rando
        //        game.zPosition = 0
        randNum.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: timer.frame.width * 1.25 , height: timer.frame.height * 2.5))
        randNum.physicsBody?.isDynamic = false
        randNum.fontSize = 30
        randNum.fontColor = SKColor.init(_colorLiteralRed: 1, green: 0.6745, blue: 0.1098, alpha: 1)
        randNum.position = CGPoint(x: frame.midX , y: 15)
        addChild(randNum)
        randNum.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        randNum.run(fadeOutAction, completion: {
            self.randNum.alpha = 1
        })
        
        
        sumShower = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        sumShower.text =  symbolsOperators[currentRound-1]   //"sum = \(sum)"
        sumShower.name = roundIdentifier
        sumShower.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: round.frame.width * 1.25 , height: round.frame.height * 2.5))
        sumShower.physicsBody?.isDynamic = false
        sumShower.fontSize = 25
        sumShower.fontColor = SKColor.init(_colorLiteralRed: 0.9, green: 0.45, blue: 0, alpha: 1)
        sumShower.position = CGPoint(x: frame.midX , y: self.frame.height - 32.5)
        addChild(sumShower)
        sumShower.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        sumShower.run(fadeOutAction, completion: {
            self.sumShower.alpha = 1
        })
        
        N1 = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        N1.text = "" //"sum = \(sum)"
        N1.name = roundIdentifier
        N1.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: round.frame.width * 1.25 , height: round.frame.height * 2.5))
        N1.physicsBody?.isDynamic = false
        N1.fontSize = 25
        N1.fontColor = SKColor.init(_colorLiteralRed: 0.9, green: 0.45, blue: 0, alpha: 1)
        N1.position = CGPoint(x: frame.midX - 37.5 , y: self.frame.height - 32.5)
        addChild(N1)
        N1.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        N1.run(fadeOutAction, completion: {
            self.N1.alpha = 1
        })
        
        N2 = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        N2.text = "" //"sum = \(sum)"
        N2.name = roundIdentifier
        N2.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: round.frame.width * 1.25 , height: round.frame.height * 2.5))
        N2.physicsBody?.isDynamic = false
        N2.fontSize = 25
        N2.fontColor = SKColor.init(_colorLiteralRed: 0.9, green: 0.45, blue: 0, alpha: 1)
        N2.position = CGPoint(x: frame.midX + 37.5 , y: self.frame.height - 32.5)
        addChild(N2)
        N2.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        N2.run(fadeOutAction, completion: {
            self.N2.alpha = 1
        })
        
        let button = ResetButton()
        button.name = buttonNodeName
        button.position = CGPoint(x: frame.width - 70, y: 25)
        button.delegate = self
        addChild(button)
        
        let wait = SKAction.wait(forDuration:0.02)
        let action = SKAction.run {
            self.addNumbersOnRandomPlaces()
        }
        
        run(SKAction.repeat(SKAction.sequence([wait, action]) , count: totalnumbers[currentRound-1]))
        
        var timeCount = totalTime[self.currentRound - 1] - 1
        let waitTimer = SKAction.wait(forDuration: 1)
        let actionTimer = SKAction.run {
            self.timer.text = "Timer : \(timeCount)"
            timeCount = timeCount - 1;
            if timeCount == -1
            {
                self.removeAllActions()
                self.isTimeOver = true
                if self.scoreValue >= self.totalScore[self.currentRound-1]
                {
                    if self.currentRound == self.noOfRounds
                    {
                        self.congratulation()
                    }
                    else
                    {
                        self.moveToNextRound()
                    }
                }
                else{
                    self.showReplayButton()
                }
            }
        }
        run(SKAction.repeat(SKAction.sequence([waitTimer, actionTimer]) , count: totalTime[self.currentRound - 1] ))
    }
    
    //Function to Show the Congratulation Message if user clears all the round
    func congratulation() {
        currentRound = 1
        let namaste = SKLabelNode(fontNamed: "Helvetica Neue")
        namaste.text = "Congratulations!"
        namaste.name = initialTextNodes
        //        namaste.zPosition = 0
        namaste.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: namaste.frame.width * 1.25 , height: namaste.frame.height * 2.5))
        namaste.physicsBody?.isDynamic = false
        namaste.fontSize = 30
        namaste.fontColor = SKColor.black
        namaste.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(namaste)
        namaste.alpha = 0
        
        var fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        namaste.run(fadeOutAction, completion: {
            namaste.alpha = 1
        })
        
        let number = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        number.text = "You Won ❤️"
        number.name = initialTextNodes
        //        number.zPosition = 0
        number.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: number.frame.width * 1.25 , height: number.frame.height * 2.5))
        number.physicsBody?.isDynamic = false
        number.fontSize = 45
        number.fontColor = SKColor.black
        number.position = CGPoint(x: frame.midX , y: frame.midY - (namaste.frame.height + 10) - 10)
        addChild(number)
        number.alpha = 0
        
        fadeOutAction = SKAction.fadeIn(withDuration: 4) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        number.run(fadeOutAction, completion: {
            number.alpha = 1
        })
        
        
        let button = ResetButton()
        button.name = buttonNodeName
        button.position = CGPoint(x: frame.midX, y: frame.midY - 10 - (namaste.frame.height + 10) - (number.frame.height + 10))
        button.delegate = self
        addChild(button)
        button.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 1.5) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        button.run(fadeOutAction, completion: {
            button.alpha = 1
        })
    }
    
    
    //Function to show the Next Round Button
    func moveToNextRound() {
        count = 0
        sum = 0
        product = 1
        answer = 0
        
        let namaste = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        namaste.text = "You Won ❤️"
        namaste.name = initialTextNodes
        //        namaste.zPosition = 0
        namaste.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: namaste.frame.width * 1.25 , height: namaste.frame.height * 2.5))
        namaste.physicsBody?.isDynamic = false
        namaste.fontSize = 30
        namaste.fontColor = SKColor.black
        namaste.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(namaste)
        namaste.alpha = 0
        
        var fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        namaste.run(fadeOutAction, completion: {
            namaste.alpha = 1
        })
        
        
        
        let button = NextButton()
        button.name = buttonNodeName
        button.position = CGPoint(x: frame.midX, y: frame.midY - (namaste.frame.height + 10))
        button.delegate = self
        button.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: button.frame.width * 1.25 , height: button.frame.height * 2.5))
        button.physicsBody?.isDynamic = false
        addChild(button)
        button.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 1.5) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        button.run(fadeOutAction, completion: {
            button.alpha = 1
        })
        
        let action = SKAction.playSoundFileNamed("VictorySound", waitForCompletion: false)
        self.run(action)
        
    }
    
    //Function to Show Replay Button if user loses the round
    func showReplayButton() {
        
        let namaste = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        namaste.text = "You Lose 😭"
        namaste.name = initialTextNodes
        //        namaste.zPosition = 0
        namaste.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: namaste.frame.width * 1.25 , height: namaste.frame.height * 2.5))
        namaste.physicsBody?.isDynamic = false
        namaste.fontSize = 30
        namaste.fontColor = SKColor.black
        namaste.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(namaste)
        namaste.alpha = 0
        
        
        var fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        namaste.run(fadeOutAction, completion: {
            namaste.alpha = 1
        })
        
        
        let button = ResetButton()
        button.name = buttonNodeName
        button.position = CGPoint(x: frame.midX, y: frame.midY - (namaste.frame.height + 10))
        button.delegate = self
        addChild(button)
        button.alpha = 0
        fadeOutAction = SKAction.fadeIn(withDuration: 1.5) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        button.run(fadeOutAction, completion: {
            button.alpha = 1
        })
        
        let action = SKAction.playSoundFileNamed("Defeat", waitForCompletion: false)
        self.run(action)
        
    }
    
    //Function to remove numbers if they go out of the View
    override public func didSimulatePhysics() {
        super.didSimulatePhysics()
        // Remove nodes if they're outside the view
        enumerateChildNodes(withName: wwdcIconName) { (node, stop) in
            if node.position.y < -50 || node.position.y > self.frame.size.height + 50 || node.position.x < -50 || node.position.x > self.frame.size.width + 50 {
                node.removeFromParent()
            }
        }
    }
    
    //function to Detect the change in the view Size
    public override func didChangeSize(_ oldSize: CGSize) {
        //        resetLogoPosition()
        resetButtonPosition()
    }
    
    // MARK: Helper Functions
    
    //    func resetLogoPosition() {
    //        guard let logo = childNode(withName: logoNodeName) else { return }
    //        logo.position = CGPoint(x: frame.midX, y: frame.midY)
    //    }
    
    func resetButtonPosition() {
        guard let button = childNode(withName: buttonNodeName) else { return }
        button.position = CGPoint(x: frame.width - 50, y: 50)
    }
    
    //Hides and show button function when user taps.
    func hideButton() {
        guard let button = childNode(withName: buttonNodeName) else { return }
        let fadeOutAction = SKAction.fadeOut(withDuration: 0.25)
        fadeOutAction.timingMode = .easeInEaseOut
        button.run(fadeOutAction)
    }
    
    func showButton() {
        guard let button = childNode(withName: buttonNodeName) else { return }
        let fadeInAction = SKAction.fadeIn(withDuration: 0.25)
        fadeInAction.timingMode = .easeInEaseOut
        button.run(fadeInAction)
    }
    
    // MARK: Touch Handling
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        hideButton()
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesMoved(touches, with: event)
        for touch in touches {
            let location = touch.location(in: self)
            if isInitialScene {
                createRandomnumber(at: location)
            }
            
        }
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        showButton()
        
    }
    
    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesCancelled(touches, with: event)
        showButton()
    }
}

// MARK: ResetButtonDelegate
extension MainScene: ResetButtonDelegate {
    
    func didTapReset(sender: ResetButton) {
        self.isInitialScene = false
        self.scoreValue = 0
        self.isTimeOver = false
        sum = 0
        count = 0
        randNumber = getRandomNumber()
        self.setUpScene()
        
    }
}

//MARK : GamenumberButtonDelegate
extension MainScene : TouchableSpriteTextNodeDelegate{
    
    //Handles when user clicks on the number and adds an Animation.
    func didTap(sender: TouchableSpriteTextNode) {
        let value = Int(sender.name ?? "0")
        count += 1
        if currentRound == 1 {
            sum += Double(value ?? 0)
            answer = sum
        } else if currentRound == 2 {
            if count == 1 { sum += Double(value ?? 0) }
            if count == 2 { sum -= Double(value ?? 0) }
            answer = sum
        } else if currentRound == 3 {
            product *= Double(value ?? 1)
            answer = product
        } else if currentRound == 4 {
            if count == 1 { product *= Double(value ?? 0) }
            if count == 2 { product /= Double(value ?? 0) }
            answer = product
        }
//        self.sumShower.text = "sum = \(sum)"
        
        if count == 1 {
            N1.text = "\(value ?? 0)"
            N1.alpha = 1
        }
        
        if count == 2 {
            N2.text = "\(value ?? 0)"
            N2.alpha = 1
            
            var fadeOutAction = SKAction.fadeOut(withDuration: 0.25) //SKAction.fadeOut(withDuration: 1.25)
            fadeOutAction.timingMode = .easeInEaseOut
            N1.run(fadeOutAction, completion: { [weak self] in
            guard let self = self else { return }
                self.N1.text = " "
            })
            
            fadeOutAction = SKAction.fadeOut(withDuration: 0.25) //SKAction.fadeOut(withDuration: 1.25)
            fadeOutAction.timingMode = .easeInEaseOut
            N2.run(fadeOutAction, completion: { [weak self] in
            guard let self = self else { return }
                self.N2.text = " "
            })
            
            
            if answer == Double(randNumber) {
                scoreValue += 2
                score.fontColor = SKColor.init(_colorLiteralRed: 0.1, green: 0.76, blue: 0.1, alpha: 1)
                randNumber = getRandomNumber()
                randNum.text = "Number: \(randNumber)"
                sumShower.text = "✅ Right ✅"

            } else {
                scoreValue -= 1
                score.fontColor = SKColor.init(_colorLiteralRed: 1, green: 0.2, blue: 0.2, alpha: 1)
                randNumber = getRandomNumber()
                randNum.text = "Number: \(randNumber)"
                sumShower.text = "❌ Wrong ❌"

            }
            
            fadeOutAction = SKAction.fadeOut(withDuration: 3) //SKAction.fadeOut(withDuration: 1.25)
            fadeOutAction.timingMode = .easeInEaseOut
            sumShower.run(fadeOutAction, completion: { [weak self] in
            guard let self = self else { return }
                self.sumShower.alpha = 1
                self.sumShower.text = self.symbolsOperators[self.currentRound-1]
//                self.N1.text = " "
//                self.N2.text = " "
            })
            count = 0
            sum = 0
            product = 1
            answer = 0
        }
        
        score.text = "Score : \(scoreValue)"
        

        let burstEmoji = "💥"
        let emoji1 = SKLabelNode(fontNamed: "Helvetica Neue")
        emoji1.text = burstEmoji
        emoji1.name = initialTextNodes
        emoji1.fontSize = 35
        emoji1.fontColor = SKColor.black
        emoji1.position = CGPoint(x: sender.position.x, y: sender.position.y)
        addChild(emoji1)
        var fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        emoji1.run(fadeOutAction, completion: {
            emoji1.removeFromParent()
        })
        

        
        let fadeOutActions = SKAction.fadeOut(withDuration: 0.05)
        fadeOutActions.timingMode = .easeInEaseOut
        sender.run(fadeOutActions, completion: {
            sender.removeFromParent()
            self.addNumbersOnRandomPlaces()
        })
    }
    
    func getRandomNumber() -> Int {
        var number = 0
        if currentRound == 1 {
            number = 3 + GKRandomSource.sharedRandom().nextInt(upperBound: 15) + GKRandomSource.sharedRandom().nextInt(upperBound: 11)
        } else if currentRound == 2 {
            number = 1 + GKRandomSource.sharedRandom().nextInt(upperBound: 12)
        } else if currentRound == 3 {
            let firstNumber = 2 + GKRandomSource.sharedRandom().nextInt(upperBound: 6)
            let secondNumber = 2 + GKRandomSource.sharedRandom().nextInt(upperBound: 7)
            number = firstNumber * secondNumber
        } else if currentRound == 4 {
            number = 2 + GKRandomSource.sharedRandom().nextInt(upperBound: 6)
        }
        return number
    }
}

//MARK : NextButtonDelegate

extension MainScene : NextButtonDelegate {
    func didTapNext(sender: NextButton) {
        self.currentRound = self.currentRound + 1
        self.randNumber = getRandomNumber()
        self.isInitialScene = false
        self.scoreValue = 0
        self.isTimeOver = false
        self.sum = 0
        self.count = 0
        self.setUpScene()
    }
}


// MARK: PlayButtonDelegate

extension MainScene: PlayButtonDelegate {
    
    func didTapPlay(sender: PlayButton) {
        
      //Changing Gravity to add the Initial Play Game button Click Animation when emoji drops.
        physicsWorld.gravity = CGVector.init(dx: 0, dy: +1)
        self.hideButton()
        let wait = SKAction.wait(forDuration: 4)
        let action = SKAction.run {
            self.enumerateChildNodes(withName: self.wwdcIconName) { (node, stop) in
                let fadeOutAction = SKAction.fadeOut(withDuration: 0.25)
                fadeOutAction.timingMode = .easeInEaseOut
                node.run(fadeOutAction, completion: {
                    node.removeFromParent()
                })
            }
            self.enumerateChildNodes(withName: self.initialTextNodes) { (node, stop) in
                let fadeOutAction = SKAction.fadeOut(withDuration: 1)
                fadeOutAction.timingMode = .easeInEaseOut
                node.run(fadeOutAction, completion: {
                    node.removeFromParent()
                })
            }
            //                self.removeFromParent()
            
            self.enumerateChildNodes(withName: self.buttonNodeName) { (node, stop) in
                let fadeOutAction = SKAction.fadeOut(withDuration: 1)
                fadeOutAction.timingMode = .easeInEaseOut
                node.run(fadeOutAction, completion: {
                    node.removeFromParent()
                    self.removeAllActions()
                    self.isInitialScene = false
                    self.setnumberArray()
                    self.setUpScene()
                    
                })
            }
        }
        
        run(SKAction.repeatForever(SKAction.sequence([wait, action])))
    }
}



